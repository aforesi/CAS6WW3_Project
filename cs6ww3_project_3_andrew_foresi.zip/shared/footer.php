<!-- Standard footer with copyright -->
<footer>
	<p>Team Building Copyright &copy; 2019</p>
</footer>
